1. cd into S/L/E delete(or add .dackup to disable) IO80211Family.kext and IO80211FamilyV2.kext and corecapture.kext

2. use Kext Wizard to repair perm and clean cache, install these three kexts to /S/L/E

3. repair perm and clean cache

4. reboot


